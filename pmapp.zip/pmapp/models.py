from django.db import models

class Course(models.Model):
    coursename = models.CharField(max_length=200)
    
class Student(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    sname = models.CharField(max_length=200)
    fees = models.IntegerField(default=0)
    mobie = models.CharField(max_length=100)


class Country(models.Model):
    countryname = models.CharField(max_length=50)
    def __str__(self):
    	return self.countryname

class State(models.Model):
	country = models.ForeignKey(Country,on_delete=models.CASCADE)
	statename = models.CharField(max_length=50)
	def __str__(self):
		return self.statename


class City(models.Model):
	state = models.ForeignKey(State,on_delete=models.CASCADE)
	cityname = models.CharField(max_length=50)
	def __str__(self):
		return self.cityname
             