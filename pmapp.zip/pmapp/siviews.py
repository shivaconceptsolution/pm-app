from django.shortcuts import render
from django.views import View
from django.http import HttpResponse

class Si(View):
	def get(self,request):
		return render(request,"pmapp/si.html")
	def post(self,request):
		a,b,c = request.POST["txtnum1"],request.POST["txtnum2"],request.POST["txtnum3"]
		si = (float(a)*float(b)*float(c))/100
		return render(request,"pmapp/si.html",{"res":si,"p":a,"r":b,"t":c})	