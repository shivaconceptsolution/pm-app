from django.urls import path
from . import views

urlpatterns=[
path('',views.index,name='index'),
path('student',views.student,name='student'),
path('course',views.course,name='course'),
path('viewstudent',views.viewstudent,name='viewstudent'),
path('viewcountry',views.viewcountry,name='viewcountry'),
path('viewstate',views.viewstate,name='viewstate'),
path('viewcity',views.viewcity,name='viewcity')

]