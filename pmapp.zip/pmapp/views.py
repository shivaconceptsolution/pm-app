from django.shortcuts import render
from django.views import View
from django.http import HttpResponse
from .models import Course, Student, Country,State
def index(request):
	obj = Course(coursename='PHP')
	obj.save()
	return HttpResponse("data inserted Successfully")

def student(request):
	obj = Student(course_id=4,sname='XYZ',fees=45000,mobie='9893913662')
	obj.save()
	return HttpResponse("data inserted Successfully")

def  course(request):
	obj = Course.objects.all()
	return render(request,"pmapp/course.html",{"res":obj})

def  viewstudent(request):
	crs = Course.objects.get(pk=request.GET["q"])
	stu = crs.student_set.all()
	return render(request,"pmapp/viewstudent.html",{"res":stu})

def viewcountry(request):
	cnt = Country.objects.all()
	return render(request,"pmapp/viewcountry.html",{"res":cnt})
def viewstate(request):
	cn = Country.objects.get(pk=request.GET["q"])
	st = cn.state_set.all()
	return render(request,"pmapp/viewstate.html",{"res":st})	
def viewcity(request):
	sn = State.objects.get(pk=request.GET["q"])
	ct = sn.city_set.all()
	return render(request,"pmapp/viewcity.html",{"res":ct})	
'''
from django.views.generic.edit import CreateView
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import UpdateView
from django.views.generic.edit import DeleteView
from .models import StudentsModel
# Create your views here.

class StudentCreate(CreateView):
	model = StudentsModel
	fields = ['rno','sname','branch','fees']
	success_url = "viewstudent"

class StudentList(ListView):
	model = StudentsModel

class StudentDetailView(DetailView):
   	model = StudentsModel

class StudentUpdate(UpdateView):
	model = StudentsModel
	fields = ['rno','sname','branch','fees']
	success_url = "/pm/viewstudent"

class StudentDelete(DeleteView):
	model = StudentsModel
	success_url = "/pm/viewstudent"
def success(request):
	return HttpResponse("Operation Successfully")

class Hello(View):
	def get(self,request):
		return render(request,"pmapp/index.html")
	def post(self,request):
		return HttpResponse(request.POST["txtname"])

class Swap(View):
	def get(self,request):
		return render(request,"pmapp/swap.html")
	def post(self,request):
		a,b = request.POST["txtnum2"],request.POST["txtnum1"]
		return render(request,"pmapp/swap.html",{"a":a,"b":b,"res":"a="+a + " b= "+b})	
		'''